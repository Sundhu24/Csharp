﻿namespace ProjectManagementAPI.Services.UserService
{
    public interface IUserService
    {
        string GetMyName();
    }
}
